# 페이스북 크롤링
import requests,re
import sys
import pymysql
import datetime,time
import pymysql
from requests import Session
from requests.packages.urllib3.util import Retry
from requests.adapters import HTTPAdapter
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from snsFun import *

# CGV = https://www.facebook.com/pg/CJCGV/posts/
# 메가박스 = https://www.facebook.com/pg/megaboxon/posts/
# 롯데시네마 = https://www.facebook.com/pg/LotteCinema.kr/posts/

def startCrawling():
    content_check = '';pageKey = '메가박스';sns_subcontent = ''
    try:
        chrome_options = Options()
        chrome_options.add_argument("--disable-notifications")
        driver = webdriver.Chrome("c:\python36\driver\chromedriver", chrome_options=chrome_options)
        driver.get('https://www.facebook.com/pg/megaboxon/posts/')
        time.sleep(3)
        for i in range(10):
            try:
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(3)
            except:
                pass
        try:
            driver.find_element_by_xpath('//*[@id="expanding_cta_close_button"]').click()
        except:
            pass
        html = driver.find_elements_by_class_name("_1xnd")[0].get_attribute('innerHTML')
        soup = BeautifulSoup(html,'html.parser')
        div =  soup.find_all("div", "_4-u2")

        for item in div:
            sns_content = item.find("div","_1dwg").find("div","_5pbx").text.strip()
            sns_content = remove_emoji(sns_content)
            if content_check == sns_content:
                continue
            content_check = sns_content
            urlEle = item.find("abbr").parent
            abbr = urlEle.find('abbr')
            url = (urlEle['href'].find('https://www.facebook.com') == -1) and 'https://www.facebook.com'+urlEle['href'] or urlEle['href']
            if url.find('photos') != -1:
                url = url.split('&__')[0]
            else:
                url = url.split('?__')[0]
            writeDate = settingDate(abbr)

            if url.find('videos') != -1:
                r = requests.get(url)
                c = r.content
                soup = BeautifulSoup(c,"html.parser")
                text = str(soup)
                view_cnt = text.split('조회')[1].split('회')[0].replace(',', '').strip()
            else:
                view_cnt = 0


            like_cnt = item.find('span', '_3dlh').text.strip()
            if like_cnt.find('.') != -1 and like_cnt.find('천') != -1:
                like_cnt = like_cnt.split('천')[0].replace('.', '')+'00'
            elif like_cnt.find('천') != -1:
                like_cnt = like_cnt.split('천')[0]+'000'
            elif like_cnt.find('.') != -1 and like_cnt.find('만') != -1:
                like_cnt = like_cnt.split('만')[0].replace('.', '')+'000'
            elif like_cnt.find('만') != -1:
                like_cnt = like_cnt.split('만')[0]+'0000'

            reply_cnt = item.find('span', '_1whp').text.split('댓글')[1].strip()
            if reply_cnt.find('.') != -1 and reply_cnt.find('천') != -1:
                reply_cnt = reply_cnt.split('천')[0].replace('.', '')+'00'
            elif reply_cnt.find('천') != -1:
                reply_cnt = reply_cnt.split('천')[0]+'000'
            elif reply_cnt.find('.') != -1 and reply_cnt.find('만') != -1:
                reply_cnt = reply_cnt.split('만')[0].replace('.', '')+'000'
            elif reply_cnt.find('만') != -1:
                reply_cnt = reply_cnt.split('만')[0]+'0000'
            else:
                reply_cnt = reply_cnt.split('개')[0]

            share_cnt = item.find('span', '_355t').text.split('공유')[1].strip()
            if share_cnt.find('.') != -1 and share_cnt.find('천') != -1:
                share_cnt = share_cnt.split('천')[0].replace('.', '')+'00'
            elif share_cnt.find('천') != -1:
                share_cnt = share_cnt.split('천')[0]+'000'
            elif share_cnt.find('.') != -1 and share_cnt.find('만') != -1:
                share_cnt = share_cnt.split('만')[0].replace('.', '')+'000'
            elif share_cnt.find('만') != -1:
                share_cnt = share_cnt.split('만')[0]+'0000'
            else:
                share_cnt = share_cnt.split('회')[0]

            data = {
                'sns_content' : sns_content,
                'sns_subcontent' : sns_subcontent,
                'url' : url,
                'like_cnt' : like_cnt,
                'reply_cnt' : reply_cnt,
                'share_cnt' : share_cnt,
                'view_cnt' : view_cnt,
                'writeDate' : writeDate
            }
            # print(data)
            # print("=================================")

            conn = pymysql.connect(host='49.247.5.169',user='overware',password='uni1004!@',db='union',charset='utf8')
            curs = conn.cursor(pymysql.cursors.DictCursor)
            getView = getSearchView(url,conn,curs)
            getLike = getSearchLike(url,conn,curs)
            getReply = getSearchReply(url,conn,curs)

            gview_cnt = int(view_cnt) - getView
            glike_cnt = int(like_cnt) - getLike
            greply_cnt = int(reply_cnt) - getReply
            GetSubcontents = getSubcontents(url,conn,curs)

            insert(conn,pageKey,sns_content,GetSubcontents,url,like_cnt,reply_cnt,share_cnt,view_cnt,writeDate)
            insert2(pageKey,url,gview_cnt,glike_cnt,greply_cnt,writeDate)
    except:
        pass
    finally:
        driver.close()

if __name__=='__main__':
    start_time = time.time()

    print("메가박스 크롤링 시작")
    startCrawling()
    print("메가박스 크롤링 끝")
    print("--- %s seconds ---" %(time.time() - start_time))
    print("=================================")
